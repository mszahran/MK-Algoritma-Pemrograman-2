import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input golongan karyawan
        System.out.print("Masukkan golongan karyawan (A/B/C): ");
        char golongan = scanner.next().toUpperCase().charAt(0);

        // Input jumlah jam lembur
        System.out.print("Masukkan jumlah jam lembur: ");
        int jamLembur = scanner.nextInt();

        // Deklarasi variabel gaji pokok dan gaji lembur
        double gajiPokok = 0;
        double gajiLembur = 0;

        // Tentukan gaji pokok berdasarkan golongan
        if (golongan == 'A') {
            gajiPokok = 5000000;
        } else if (golongan == 'B') {
            gajiPokok = 6500000;
        } else if (golongan == 'C') {
            gajiPokok = 9500000;
        } else {
            System.out.println("Golongan tidak valid!");
            return;
        }

        // Hitung gaji lembur berdasarkan jumlah jam lembur
        if (jamLembur == 1) {
            gajiLembur = gajiPokok * 0.30;
        } else if (jamLembur == 2) {
            gajiLembur = gajiPokok * 0.32;
        } else if (jamLembur == 3) {
            gajiLembur = gajiPokok * 0.34;
        } else if (jamLembur == 4) {
            gajiLembur = gajiPokok * 0.36;
        } else if (jamLembur >= 5) {
            gajiLembur = gajiPokok * 0.38;
        }

        // Hitung total penghasilan
        double totalPenghasilan = gajiPokok + gajiLembur;

        // Tampilkan hasil
        System.out.println("\n--- Hasil Perhitungan ---");
        System.out.println("Golongan Karyawan: " + golongan);
        System.out.println("Gaji Pokok: Rp. " + gajiPokok);
        System.out.println("Gaji Lembur: Rp. " + gajiLembur);
        System.out.println("Total Penghasilan: Rp. " + totalPenghasilan);
    }
}
